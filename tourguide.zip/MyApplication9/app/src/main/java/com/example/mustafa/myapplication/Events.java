package com.example.mustafa.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Events extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);
        final ArrayList<Guide> guideArrayArrayList=new ArrayList<>();

        guideArrayArrayList.add(new Guide("فندق الالماسة","this hutel is very vanta",R.drawable.hotel1));
        guideArrayArrayList.add(new Guide("فندق الجزيره","this hutel is very vanta",R.drawable.hotel1));
        guideArrayArrayList.add(new Guide("فندق هيلتون","this hutel is very vanta",R.drawable.hotel1));
        guideArrayArrayList.add(new Guide("فندق الجوهرة","this hutel is very vanta",R.drawable.hotel1));

        AdapterGuide adapterGuide=new AdapterGuide(this,guideArrayArrayList);

        ListView listView=(ListView)findViewById(R.id.list_item_hotel);
        listView.setAdapter(adapterGuide);


    }
}