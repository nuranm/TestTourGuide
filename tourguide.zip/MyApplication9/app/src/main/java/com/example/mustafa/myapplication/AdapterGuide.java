package com.example.mustafa.myapplication;


import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterGuide extends ArrayAdapter<Guide> {
    private static final String LOG_TAG = AdapterGuide.class.getSimpleName();

    /**
     * @param context The current context. Used to inflate the layout file.
     * @param Guide   A List of sound objects to display in a list
     */
    public AdapterGuide(Activity context, ArrayList<Guide> Guide) {

        super(context, 0, Guide);
    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_items, parent, false);
        }
        Guide currentAndroidFlavor = getItem(position);
        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView nameTextView = (TextView) listItemView.findViewById(R.id.textView);
        nameTextView.setText(currentAndroidFlavor.getNameHutile());
        TextView numberTextView = (TextView) listItemView.findViewById(R.id.textView2);
        numberTextView.setText(currentAndroidFlavor.getDetails());
        ImageView imageView =(ImageView)listItemView.findViewById(R.id.imageView);
        imageView.setImageResource(currentAndroidFlavor.getMpictuer());
        return listItemView;
    }

}
