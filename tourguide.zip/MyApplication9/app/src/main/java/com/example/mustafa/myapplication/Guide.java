package com.example.mustafa.myapplication;

public class Guide {
    private String mNameHutile;
    private String mDetails;
    private int mpictuer;
    public Guide(String nameHutile, String details, int pictuer) {
        mNameHutile = nameHutile;
        mDetails = details;
        mpictuer=pictuer;
    }


    public String getNameHutile() {
        return mNameHutile;
    }

    public String getDetails() {
        return mDetails;
    }

    public int getMpictuer() {
        return mpictuer;
    }
}
